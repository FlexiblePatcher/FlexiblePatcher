HOW TO USE PARTICLE TESTING GROUND:

1. Launch "tomb4.exe" IN WINDOWED MODE. Go to test level and push one of the levers to activate smoke emitter (ground or elevated one).

2. Launch "particle-test.exe". In this application you can edit all parameters except spawn interval.

3. Launch "spawn-interval.exe". Here you can edit spawn interval.



In these applications, you can set any value for smoke emitter. To set it, enter new value and click checkbox on the left.
Values are similar to FLEP's steam emitter properties.


You can have both "particle-test.exe" and "spawn-interval.exe" launched at the same time.

Also, you can create your own test level with classic TRLE or Dxtre3d. Just put there some smoke_emitter_white objects with OCB 0